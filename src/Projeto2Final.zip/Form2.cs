﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace idea
{
    public partial class Form2 : Form
    {

        PontosProv pontosprov = new PontosProv(); 
        Region areaCorsica;
        Region areaParis;
        bool selecionada = false;

        public Form2()
        {
            InitializeComponent();
            this.MaximizeBox = false;

            CriarProvinciaCorsi();
            CriarProvinciaParis();

            pictureBox1.Paint += pictureBox1_Paint;
            pictureBox1.MouseClick += pictureBox1_MouseClick;
        }

        void CriarProvinciaCorsi()
        {
            GraphicsPath Corsica = new GraphicsPath();
            Corsica.AddPolygon(pontosprov.ProvinciaCOR.ToArray());
            areaCorsica = new Region(Corsica);
        }
        void CriarProvinciaParis()
        {
            GraphicsPath Paris = new GraphicsPath();
            Paris.AddPolygon(pontosprov.ProvinciaParis.ToArray());
            areaParis = new Region(Paris);
        }

        void CriarProvinciaCalais()
        {
            GraphicsPath Calais = new GraphicsPath();
            Calais.AddPolygon(pontosprov.ProvinciaCalais.ToArray());
            areaParis = new Region(Calais);
        }


        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            Graphics gCOR = e.Graphics;

            Color corFRA = Color.LightBlue;

            gCOR.FillPolygon(new SolidBrush(corFRA), pontosprov.ProvinciaCOR.ToArray());
            gCOR.DrawPolygon(Pens.Black, pontosprov.ProvinciaCOR.ToArray());
        }

        private void ProvinciaParis_Paint(object sender, PaintEventArgs e)
        {
            Graphics gCOR = e.Graphics;

            Color corFRA = Color.LightBlue;

            gCOR.FillPolygon(new SolidBrush(corFRA), pontosprov.ProvinciaParis.ToArray());
            gCOR.DrawPolygon(Pens.Black, pontosprov.ProvinciaParis.ToArray());
        }
        private void ProvinciaCalais_Paint(object sender, PaintEventArgs e)
        {
            Graphics gCOR = e.Graphics;

            Color corFRA = Color.LightBlue;

            gCOR.FillPolygon(new SolidBrush(corFRA), pontosprov.ProvinciaCalais.ToArray());
            gCOR.DrawPolygon(Pens.Black, pontosprov.ProvinciaCalais.ToArray());
        }



        private void pictureBox1_MouseClick(object sender, MouseEventArgs e)
        {

            if (areaCorsica.IsVisible(e.Location))
            {
                selecionada =! selecionada; 

                MessageBox.Show("Clicaste na província!");
            }

            pictureBox1.Invalidate();
        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
    }
}
