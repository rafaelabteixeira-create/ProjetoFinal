﻿using System.Collections.Generic;
using System.Drawing;

namespace idea
{
    internal class Provincia
    {
        private string v;
        private List<Point> points;

        public Provincia(string v, List<Point> points)
        {
            this.v = v;
            this.points = points;
        }
    }
}