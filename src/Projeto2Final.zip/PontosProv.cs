﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace idea
{
    internal class PontosProv
    {

        public List<Point> ProvinciaCOR = new List<Point>()
{
        new Point(58,65),
        new Point(61,43),
        new Point(67,50),
        new Point(63,67),
        new Point(68,78),
        new Point(69,90),
        new Point(70,97),
        new Point(61,111),
        new Point(62,121),
        new Point(49,153),
        new Point(43,143),
        new Point(32,138),
        new Point(32,86),
        new Point(58,65)
        };

        public List<Point> ProvinciaParis = new List<Point>()
{
           new Point(60,57),
new Point(78,76),
new Point(74,95),
new Point(53,106),
new Point(34,96),
new Point(29,77),
new Point(36,62),
new Point(58,57)
        };
        public List<Point> ProvinciaCalais = new List<Point>()
{
        new Point(227,502),
new Point(242,506),
new Point(316,562),
new Point(340,556),
new Point(358,576),
new Point(464,552),
new Point(476,531),
new Point(446,524),
new Point(426,485),
new Point(409,497),
new Point(389,489),
new Point(362,442),
new Point(340,430),
new Point(337,413),
new Point(303,419),
new Point(293,464),
new Point(228,496),
new Point(226,502),
new Point(36,62),
new Point(58,57)    
        };

    }
}
