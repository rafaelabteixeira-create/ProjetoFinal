﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace idea
{
    internal class PontosProv
    {
        

        public List<Point> ProvinciaCOR = new List<Point>()
{
        new Point(740,1001),
        new Point(743,979),
        new Point(749,986),
        new Point(745,1004),
        new Point(750,1015),
        new Point(749,1018),
        new Point(752,1033),
        new Point(744,1047),
        new Point(731,1090),
        new Point(726,1077),
        new Point(714,1071),
        new Point(704,1022),
        new Point(731,999)
        };

        public List<Point> ProvinciaParis = new List<Point>()
{
           new Point(448, 598),
    new Point(472, 592),
    new Point(490, 612),
    new Point(486, 631),
    new Point(465, 642),
    new Point(446, 632),
    new Point(441, 613),
    new Point(448, 599)
        };
        public List<Point> ProvinciaCalais = new List<Point>()
{
        new Point(448, 598),
    new Point(472, 592),
    new Point(490, 612),
    new Point(596, 587),
    new Point(608, 567),
    new Point(578, 560),
    new Point(558, 521),
    new Point(541, 533),
    new Point(521, 525),
    new Point(494, 479),
    new Point(472, 467),
    new Point(469, 449),
    new Point(435, 455),
    new Point(425, 500),
    new Point(360, 531),
    new Point(359, 538),
    new Point(374, 542),
    new Point(448, 598)

        };

        public List<Point> ProvinciaNormandy = new List<Point>()
        {
            new Point(287, 579),
            new Point(295, 519),
            new Point(308, 541),
            new Point(374, 542),
            new Point(425, 581),
            new Point(386, 618),
    new Point(306, 614),

        };
        public List<Point> ProvinciaOrleans = new List<Point>()
        {
            new Point(425,581),
            new Point(448,598),
            new Point(440,613),
            new Point(446,632),
            new Point(465,642),
            new Point(486,631),
            new Point(490,612),
            new Point(590,587),
            new Point(606,601),
            new Point(654,625),
            new Point(640,695),
            new Point(641,707),
            new Point(615,732),
            new Point(590,775),
            new Point(543,730),
            new Point(405,724),
            new Point(350,616),
            new Point(386,618),

        };
        

        }
}
