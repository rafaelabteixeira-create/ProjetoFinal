﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace idea
{
    public partial class Entrar : Form
    {
        private static string _connectionString = "Server = (localdb)\\MSSQLLocalDB; Database = Projeto2Ano; Trusted_Connection = True";

        private static SqlConnection db = new SqlConnection(_connectionString);
        public Entrar()
        {
            InitializeComponent();

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form3 MapaF = new Form3();

            if (textBox1.Text == "")
            {
                MessageBox.Show("Intruduza o nome da Conta");
            }
            else if (textBox2.Text == "")
            {
                MessageBox.Show("Intruduza a sua palavra-passe");
            }
            else
            {
                MapaF.Show();
                this.Hide();
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Criar criar = new Criar();
            criar.Show();
            this.Hide();
        }
    }
}
