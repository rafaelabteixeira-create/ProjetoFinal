﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace idea
{
    public partial class Criar : Form
    {
        public Criar()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Entrar mainF = new Entrar();
            Application.Exit();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form3 MapaF = new Form3();

            if (textBox1.Text == "")
            {
                MessageBox.Show("Intruduza o nome da Conta");
            }
            else if (textBox2.Text == "")
            {
                MessageBox.Show("Intruduza a sua palavra-passe");
            }
            else
            {
                MapaF.Show();
                this.Hide();
            }
        }
    }
}
