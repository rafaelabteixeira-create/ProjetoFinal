﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace idea
{
   public class ClassDatabase
    {     
        

        public static string connectionString = "Server = (localdb)\\MSSQLLocalDB; Database = Projeto2Ano; Trusted_Connection = True";

        public static int Turnos2 = 0;


        public int contadorT (int contador)
        {
            contador++;

            Turnos2++;
            return contador; 
        }

        public void FocoTurno(int num)
        {
             num += Turnos2;
            MessageBox.Show($"O seu foco vai demorar {num} turnos");    
        }
        
    }
}
