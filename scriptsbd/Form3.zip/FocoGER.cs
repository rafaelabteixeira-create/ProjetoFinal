﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace idea
{
    public partial class FocoGER : Form
    {
        
        public int focoF = 3;
        public int local = 0;
        ClassDatabase db = new ClassDatabase();
       
        public FocoGER()
        {
            InitializeComponent();
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
           db.FocoTurno(focoF);

        }

        private void FocoGER_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
